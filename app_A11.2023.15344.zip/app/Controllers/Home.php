<?php

namespace App\Controllers;

class Home extends BaseController
{
    // Menampilkan halaman utama
    public function index(): string
    {
        return view('v_home'); // Pastikan view 'v_home' ada di folder Views
    }

    // Menampilkan halaman F.A.Q
    public function faq()
    {
        return view('v_faq'); // Pastikan view 'faq' ada di folder Views
    }

    // Menampilkan halaman Contact
    public function contact()
    {
        return view('v_contact'); // Pastikan view 'contact' ada di folder Views
    }
}

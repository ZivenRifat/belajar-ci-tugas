<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

 $routes->get('/', 'Home::index', ['filter' => 'auth']); // Halaman utama
 $routes->get('faq', 'Home::faq', ['filter' => 'auth']); // Halaman F.A.Q
 $routes->get('contact', 'Home::contact', ['filter' => 'auth']);// Halaman Contact
 

$routes->get('login', 'AuthController::login');
$routes->post('login', 'AuthController::login');
$routes->get('logout', 'AuthController::logout');

$routes->get('produk', 'ProdukController::index', ['filter' => 'auth']);
$routes->get('keranjang', 'TransaksiController::index', ['filter' => 'auth']);
